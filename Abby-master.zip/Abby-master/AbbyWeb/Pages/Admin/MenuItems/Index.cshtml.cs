using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AbbyWeb.Pages.Admin.MenuItems
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
